function terms_changed(termsCheckBox) {
  if (termsCheckBox.checked) {
    document.getElementById("button_submit").disabled = false;
  } else {
    document.getElementById("button_submit").disabled = true;
  }
}

// Confirm password
function validate() {
  var password = document.getElementById("InputPassword1").value;
  var confirmPassword = document.getElementById("InputPassword2").value;
  if (password != confirmPassword) {
    alert("Passwords do not match.");
    return false;
  }
  return true;
}
